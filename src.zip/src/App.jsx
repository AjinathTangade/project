import React from "react";
import AllComponets from "./components/AllComponets";
import { Routes, Route } from "react-router-dom";
import Jobs from "./components/Jobs";
import Header from "./components/Header";
import Footer from "./components/Footer";
function App() {
  return (
    <>
    <Header />
      <Routes>
        <Route path="/" element={<AllComponets />} />
        <Route path="/jobs" element={<Jobs />} />
      </Routes>
      <Footer/>
    </>
  );
}

export default App;
