import React from "react";
import AllComponets from "./components/AllComponets";
function App() {
  return (
    <>
      <AllComponets />
    </>
  );
}

export default App;
