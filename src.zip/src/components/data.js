
export const navigation = [
  { name: "Home", href: "#", current: true },
  { name: "Team", href: "#", current: false },
  { name: "Projects", href: "#", current: false },
  { name: "Blog", href: "#", current: false },
  { name: "Pages", href: "#", current: false },
];
export const Pestimonial = [
  {
    "id": 1,
    "title": "Great Work",
    "subTitle": "“I found the course material to be highly engaging, and the instructors to be helpful and communicative.”",
    "img": "/src/assets/img/tes1.jpg",
    "author": "Courtney Henry",
    "position": "Web Designer"
  },
  {
    "id": 2,
    "title": "Good Job",
    "subTitle": "“Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium”",
    "img": "/src/assets/img/tes2.jpg",
    "author": "Ali Tufan",
    "position": "Product Manager"
  },
  {
    "id": 3,
    "title": "Perfect Work",
    "subTitle": "“Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.”",
    "img": "/src/assets/img/tes3.jpg",
    "author": "Robert Fox",
    "position": "Nursing Assistant"
  }
];
export const rate = [
  {
    "id": 1,
    "count": "4.9/5",
    "text": "Clients rate professionals on Freeio"
  },
  {
    "id": 2,
    "count": "95%",
    "text": "95% of customers are satisfied through to see their freelancers"
  },
  {
    "id": 3,
    "count": "Award winner",
    "text": "G2’s 2022 Best Software Awards"
  }
];
export const Innovative = [
  {
    id: 1,
    img: "https://tailwindui.com/img/logos/158x48/reform-logo-gray-900.svg",
  },
  {
    id: 2,
    img: "https://tailwindui.com/img/logos/158x48/transistor-logo-gray-900.svg",
  },
  {
    id: 3,
    img: "https://tailwindui.com/img/logos/158x48/tuple-logo-gray-900.svg",
  },
  {
    id: 4,
    img: "https://tailwindui.com/img/logos/158x48/statamic-logo-gray-900.svg",
  },
];
export const projects = [
  { name: "Business", href: "#" },
  { name: "Design & Creative", href: "#" },
  { name: "Development & IT", href: "#" },
  { name: "Digital Marketing", href: "#" },
  { name: "Lifestyle", href: "#" },
  { name: "Music & Audio", href: "#" },
];
export const trending = [
  { name: "Design & Creative", href: "#" },
  { name: "Development & IT", href: "#" },
  { name: "Digital Marketing", href: "#" },
  { name: "Lifestyle", href: "#" },
  { name: "Music & Audio", href: "#" },
  { name: "Video & Animation", href: "#" },
];
export const support = [
  { name: "Help & Support", href: "#" },
  { name: "FAQ Freeio", href: "#" },
  { name: "Contact Us", href: "#" },
  { name: "Services", href: "#" },
  { name: "Terms of Service", href: "#" },
];
export const latestProject = [
  {
    id: 1,
    img: "/src/assets/img/employer4.jpg",
    title: "Developer for ACG iOS apps and Website",
    subTitle: "APInter",
    location: "Miami",
    time: "Posted 1 year ago",
    proposal: "2 Proposals"
  },
  {
    id: 2,
    img: "/src/assets/img/employer1.jpg",
    title: "English Content Writer for College",
    subTitle: "MediaAZ",
    location: "Los Angeles",
    time: "Posted 1 year ago",
    proposal: "2 Proposals"
  },
  {
    id: 3,
    img: "/src/assets/img/employer8.png",
    title: "Developer to framework for web agency",
    subTitle: "Redesign",
    location: "Los Angeles",
    time: "Posted 1 year ago",
    proposal: "1 Proposal"
  },
  {
    id: 4,
    img: "/src/assets/img/employer12.jpg",
    title: "Create desktop applications with source PHP",
    subTitle: "DGSolution",
    location: "New York",
    time: "Posted 1 year ago",
    proposal: " 0 Proposals"
  },
  {
    id: 5,
    img: "/src/assets/img/employer2.jpg",
    title: "Manage my projects with Js, Css, Html",
    subTitle: "Upwork",
    location: "Los Angeles",
    time: "Posted 1 year ago",
    proposal: " 1 Proposals"
  },
  {
    id: 6,
    img: "/src/assets/img/employer2.jpg",
    title: "Website Designer Required For My Project",
    subTitle: "Upwork",
    location: "Los Angeles",
    time: "Posted 1 year ago",
    proposal: " 2 Proposals"
  }
];
export const blodDetiles = [
  {
    id: 1,
    date: "Novembar 8, 2023",
    img: "/src/assets/img/blog1.jpg",
    title: "New Apartment Nice in the Best Canadian Cities",
    subTitle: "Bringing the culture of sharing to everyone",
  },
  {
    id: 2,
    date: "Novembar 12, 2023",
    img: "/src/assets/img/blog2.jpg",
    title: "Diamond Manor Apartment in the New York and Service",
    subTitle: "Everyone bringing the culture of sharing to service",
  },
  {
    id: 3,
    date: "June 23, 2023",
    img: "/src/assets/img/blog3.jpg",
    title: "Unveils the Best Canadian Cities for Biking",
    subTitle: "Culture everyone bringing the of sharing to manor",
  },
  {
    id: 4,
    date: "Jule 15, 2023",
    img: "/src/assets/img/blog4.jpg",
    title: "Exploring Some of the Cities and Home Services",
    subTitle: "Cities culture everyone bringing the of sharing",
  },
];
export const topProjects = [
  { name: "Business", href: "#" },
  { name: "Design & Creative", href: "#" },
  { name: "Development & IT", href: "#" },
  { name: "Digital Marketing", href: "#" },
  { name: "Lifestyle", href: "#" },
  { name: "Music & Audio", href: "#" },
];
export const topTrending = [
  { name: "Design & Creative", href: "#" },
  { name: "Development & IT", href: "#" },
  { name: "Digital Marketing", href: "#" },
  { name: "Lifestyle", href: "#" },
  { name: "Music & Audio", href: "#" },
  { name: "Video & Animation", href: "#" },
];
export const topSkills = [
  { name: "Adobe Photoshop", href: "#" },
  { name: "Adobe XD", href: "#" },
  { name: "Android Developer", href: "#" },
  { name: "Developer", href: "#" },
  { name: "IOS Developer", href: "#" },
  { name: "Support Agent", href: "#" },
];
export const topJobs = [
  { name: "Developers", href: "#" },
  { name: "Digital Marketing", href: "#" },
  { name: "Android Developer", href: "#" },
  { name: "Graphics & Design", href: "#" },
  { name: "IOS Developer", href: "#" },
  { name: "Music & Audio", href: "#" },
];
export const blog = [
  {
    "id": 1,
    "img": "/src/assets/img/service12-495x370.jpg",
    "development": "Development & IT",
    "blogTile": "Web development, with HTML, CSS, JavaScript and PHP",
    "reviwes": "4.5 (2 Reviews)",
    "authorImg": "/src/assets/img/12-150x150.jpg",
    "authorName": "Agent Pakulla",
    "pricingText": "$229",
    "date":"12-Dec-2023",
  },
  {
    "id": 2,
    "img": "./src/assets/img/service9-495x370.jpg",
    "development": "Design & Creative",
    "blogTile": "Developers drop the framework folder into a new parent",
    "reviwes": "4.3 (23 Reviews)",
    "authorImg": "/src/assets/img/5.jpg",
    "authorName": "John Powell",
    "pricingText": "$39",
    "date":"13-Dec-2023",
  },
  {
    "id": 3,
    "img": "/src/assets/img/service11-495x370.jpg",
    "development": "Digital Marketing",
    "blogTile": "Flexibility & Customization with CMS vs PHP Framework",
    "reviwes": "5 (12 Reviews)",
    "authorImg": "/src/assets/img/8.jpg",
    "authorName": "Thomas Powell",
    "pricingText": "$199",
    "date":"14-Dec-2023",
  },
  {
    "id": 4,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Design & Creative",
    "blogTile": "PHP framework that you can use to create your own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"15-Dec-2023",
  },
  {
    "id": 5,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Finance & Accounting",
    "blogTile": "That you can use to PHP framework  create your own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"16-Dec-2023",
  },
  {
    "id": 6,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Lifestyle",
    "blogTile": "Customization with CMS you can use to create your own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"17-Dec-2023",
  },
  {
    "id": 7,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Lifestyle",
    "blogTile": "Your own PHP framework that you can use to create custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"18-Dec-2023",
  },
  {
    "id": 8,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Life",
    "blogTile": "Create your PHP framework that you can use to  own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"19-Dec-2023",
  },
  {
    "id": 9,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Life",
    "blogTile": "Create your PHP framework that you can use to  own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"01-Dec-2023",
  },
  {
    "id": 10,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Life",
    "blogTile": "Create your PHP framework that you can use to  own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"01-Dec-2023",
  },
  {
    "id": 11,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Life",
    "blogTile": "Create your PHP framework that you can use to  own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"01-Dec-2023",
  },
  {
    "id": 12,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Life",
    "blogTile": "Create your PHP framework that you can use to  own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"01-Dec-2023",
  },
  {
    "id": 13,
    "img": "/src/assets/img/service10-495x370.jpg",
    "development": "Life",
    "blogTile": "Create your PHP framework that you can use to  own custom",
    "reviwes": "3.2 (10 Reviews)",
    "authorImg": "/src/assets/img/bg-video-150x150.png",
    "authorName": "Ali Tufan",
    "pricingText": "$195",
    "date":"01-Dec-2023",
  },
];