// SingleProduct.js
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { blog } from "./data"; // Import your blog data or fetch it from an API

const SingleProduct = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    // Assuming you have the blog data available
    const fetchedProduct = blog.find((item) => item.id === parseInt(id));

    // If fetching from an API, make an API call here

    setProduct(fetchedProduct);
  }, [id]);

  // Render loading or error state while fetching
  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2>{product.blogTile}</h2>
      <img src={product.img} alt={product.blogTile} />
      <p>{product.development}</p>
      <p>{product.reviwes}</p>
      {/* Add more details as needed */}
    </div>
  );
};

export default SingleProduct;
